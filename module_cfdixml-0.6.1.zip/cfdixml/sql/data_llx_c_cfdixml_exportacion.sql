TRUNCATE TABLE llx_c_cfdixml_exportacion;

INSERT INTO llx_c_cfdixml_exportacion (code,label,active) VALUES ('01','01 - No aplica.',1);
INSERT INTO llx_c_cfdixml_exportacion (code,label,active) VALUES ('02','02 - Definitiva.',1);
INSERT INTO llx_c_cfdixml_exportacion (code,label,active) VALUES ('03','03 - Temporal.',1);

