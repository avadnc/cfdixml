TRUNCATE TABLE llx_c_cfdixml_metodopago;
INSERT INTO llx_c_cfdixml_metodopago (code,label,active) VALUES ('PUE','Pago en una sola exhibición',1);
INSERT INTO llx_c_cfdixml_metodopago (code,label,active) VALUES ('PPD','Pago en parcialidades o diferido',1);
