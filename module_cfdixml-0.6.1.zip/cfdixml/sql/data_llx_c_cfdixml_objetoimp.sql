TRUNCATE TABLE llx_c_cfdixml_objetoimp;

INSERT INTO llx_c_cfdixml_objetoimp (code,label,active) VALUES ('01','01 - No objeto de impuesto.',1);
INSERT INTO llx_c_cfdixml_objetoimp (code,label,active) VALUES ('02','02 - Sí objeto de impuesto.',1);
INSERT INTO llx_c_cfdixml_objetoimp (code,label,active) VALUES ('03','03 - Sí objeto del impuesto y no obligado al desglose.',1);

