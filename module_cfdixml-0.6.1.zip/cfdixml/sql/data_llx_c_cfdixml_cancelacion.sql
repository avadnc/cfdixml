TRUNCATE TABLE llx_c_cfdixml_cancelacion;

INSERT INTO llx_c_cfdixml_cancelacion (code,label,active) VALUES ('01','01 - Comprobantes emitidos con errores con relación.',1);
INSERT INTO llx_c_cfdixml_cancelacion (code,label,active) VALUES ('02','02 - Comprobantes emitidos con errores sin relación.',1);
INSERT INTO llx_c_cfdixml_cancelacion (code,label,active) VALUES ('03','03 - No se llevó a cabo la operación.',1);
INSERT INTO llx_c_cfdixml_cancelacion (code,label,active) VALUES ('04','04 - Operación nominativa relacionada en una factura global.',1);

